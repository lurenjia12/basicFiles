export const MAIN_BASE_MENU_COLLAPSE = 'MAIN_BASE_MENU_COLLAPSE'
export const a = 'a'

